module Main where

import qualified Data.Vector.Unboxed as VU
import qualified Data.ByteString.Char8 as B

main = do
  let readInt = fmap (second B.tail) . B.readInt
 
  as <- VU.unfoldrN n readInt <$> B.getLine

main :: IO ()
main = putStrLn "Hello, Haskell!"
